using System.Windows;

namespace GameLauncher
{
    public partial class App : Application
    {
    }
}