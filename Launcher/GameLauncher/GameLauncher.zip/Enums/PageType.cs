﻿namespace GameLauncher.Enums
{
    public enum PageType
    {
        Library,
        Store,
        Downloads,
        Settings
    }
}
